Pass input_file as the argument to the executable.

Run executable as follows: "Executable_name.exe input_c.txt"

Note: Make sure the full path to the input file is given. Else ensure the input file is in pwd.

Two output files are generated inter.txt and output.txt.
Final object code is available in output.txt